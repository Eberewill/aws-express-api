# .env

PORT=5000
MONGO_URI="your mongo db uri"
SMTP_HOST=
SMTP_PORT=
SMTP_EMAIL=
SMTP_PASSWORD=
FROM_EMAIL=
FROM_NAME=

## supply with your data
